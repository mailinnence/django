from django.db import models

class Candidate(models.Model):
    name = models.CharField(max_length=10)
    introduction = models.TextField()
    area = models.CharField(max_length=15)
    party_number = models.IntegerField(default=1)
    def __str__(self):
        return self.name #object를 출력하면 name이 보입니다.


class voice(models.Model):
    제목 = models.TextField()
    내용 = models.TextField()
    날짜 = models.TextField()

    def __str__(self):
        return self.날짜

class voice2(models.Model):
    a = models.TextField()
    b = models.TextField()
    c = models.TextField()

    def __str__(self):
        return self.c

class voice3(models.Model):
    a = models.TextField()
    b = models.TextField()
    c = models.TextField()

    def __str__(self):
        return self.c



class rec(models.Model):
    subject = models.TextField()
    content = models.TextField()
    day = models.TextField()

    def __str__(self):
        return self.day


class aaa(models.Model):
    a1 = models.TextField()
    a2 = models.TextField()
    a3 = models.TextField()

    def __str__(self):
        return self.a1
