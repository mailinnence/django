from django.shortcuts import render
from django.http import HttpResponse
from .models import Candidate,voice,voice3,rec,aaa #models에 정의된 Candidate를 import




def index(request):
    recs = rec.objects.all()
    str = ""
    for rec in recs:
        str += "<p>{}기호 {}번 ({})</p>".format(rec.subject, rec.content, rec.day)
    return HttpResponse(str)


def index2(request):
    candidates = Candidate.objects.all() #Candidate에 있는 모든 객체를 불러옵니다
    str = "" #마지막에 return해 줄 문자열입니다.
    for candidate in candidates:
        str += "{}기호 {}번 ({})<BR>".format(candidate.name, candidate.party_number, candidate.area) #<BR>은 html에서 다음 줄로 이동하기 위해 쓰입니다.
        str += candidate.introduction + "<P>" #<P>는 html에서 단락을 바꾸기 위해 쓰입니다.
    return HttpResponse(str)




def index(request):
    voice3s = voice3.objects.all()
    str = ""
    for voice in voice3s:
        str += "<p>{}기호 {}번 ({})</p>".format(voice.a, voice.b, voice.c)
    return HttpResponse(str)



def indexw(request):
    aaas = aaa.objects.all()
    str = ""
    for rec in aaas:
        str += "<p>{}기호 {}번 ({})</p>".format(rec.a1, rec.a2, rec.a3)
    return HttpResponse(str)






