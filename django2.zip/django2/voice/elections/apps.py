from django.apps import AppConfig


class ElectionsConfig(AppConfig):
    name = 'elections'
