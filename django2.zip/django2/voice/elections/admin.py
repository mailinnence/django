from django.contrib import admin
from .models import Candidate ,voice,voice2,voice3,rec,aaa

admin.site.register(Candidate)
admin.site.register(voice)
admin.site.register(voice2)
admin.site.register(voice3)
admin.site.register(rec)
admin.site.register(aaa)
