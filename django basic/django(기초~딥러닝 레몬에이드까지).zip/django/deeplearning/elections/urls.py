from django.urls import path, include
from . import views #.은 현재폴더의 디렉토리라는뜻. 즉 현재폴더의 views.py를 import하는것임

urlpatterns = [
path('/a', views.index),
path('/a1', views.index1),
path('/a2', views.post),
path('/a3', views.post2),
path('/lemon', views.lemon),
]
