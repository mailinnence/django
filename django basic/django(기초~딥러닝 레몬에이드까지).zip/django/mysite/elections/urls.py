from django.urls import path, include
from . import views #.은 현재폴더의 디렉토리라는뜻. 즉 현재폴더의 views.py를 import하는것임

app_name='elections'
urlpatterns = [
path('/a', views.index),
path('/a1', views.index1),
path('/a2', views.index2,name='home'),
path('/areas/<str:area>/',views.areas),
path('/polls/<int:poll_id>/' , views.polls), #이 url에 대한 요청을 views.polls가 처리하게 만듭니다.
path('/areas/<str:area>/results', views.results),
path('/candidates/<str:name>', views.candidates),
path('/ai', views.ai)
]
