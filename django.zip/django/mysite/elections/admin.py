from django.contrib import admin
from .models import Candidate,Poll

admin.site.register(Candidate)
admin.site.register(Poll)


