from django.shortcuts import render
from django.http import HttpResponse
import datetime
from django.http import HttpResponseRedirect
from django.db.models import Sum
from django.http import HttpResponseNotFound #추가

# 라이브러리 사용
import tensorflow as tf
import pandas as pd


def index(request):
    return HttpResponse("Hello world")


#get 방식
def index1(request):
    if request.GET.get('val') != None:
        val = request.GET.get('val')
        val=int(val)
        val=val*2
        val2 ={ 'val2' : val }
        return render(request, 'elections/index.html', val2)
    else:
        return render(request, 'elections/index.html')


#post 방식
def post(request):
    return render(request, 'elections/post.html')



def post2(request):
    if request.POST.get('val') != None:
        val = request.POST.get('val')
        val=int(val)
        val=val*2
        val2 ={ 'val2' : val }
        return render(request, 'elections/post2.html', val2)



def lemon(request):
    if request.GET.get('val') != None and request.GET.get('val').isdigit():
        val = request.GET.get('val')
        val=float(val)
        파일경로 = 'https://raw.githubusercontent.com/blackdew/tensorflow1/master/csv/lemonade.csv'
        레모네이드 = pd.read_csv(파일경로)
        레모네이드.head()

        독립 = 레모네이드[['온도']]
        종속 = 레모네이드[['판매량']]

        # 모델을 만듭니다.
        X = tf.keras.layers.Input(shape=[1])
        Y = tf.keras.layers.Dense(1)(X)
        model = tf.keras.models.Model(X, Y)
        model.compile(loss='mse')

        model.fit(독립, 종속, epochs=5000)

        val2 ={ 'val2' : model.predict([[val]]) ,
         'val':request.GET.get('val')

        }
        return render(request, 'elections/lemon.html', val2)
    else:
        return render(request, 'elections/lemon.html')











