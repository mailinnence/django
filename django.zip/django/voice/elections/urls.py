from django.urls import path, include
from . import views #.은 현재폴더의 디렉토리라는뜻. 즉 현재폴더의 views.py를 import하는것임
from django.conf.urls.static import static
from django.conf.urls import  include, url
from django.conf import settings




urlpatterns = [

path('/voice', views.voice),
path('/record', views.record),
path('/reload', views.rel),
path('/reset', views.reset),
path('/a', views.index),
path('/list', views.list),
path('/show', views.abc),
path('/save', views.save),
path('/save2', views.save2),
path('/dell', views.dell),

]


