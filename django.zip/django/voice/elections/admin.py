from django.contrib import admin
from .models import voice,rec,voice3,aaa

admin.site.register(voice)
admin.site.register(rec)
admin.site.register(voice3)
admin.site.register(aaa)










