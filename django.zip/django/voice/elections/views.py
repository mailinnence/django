from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import datetime
from django.http import HttpResponseRedirect
from django.db.models import Sum
from django.http import HttpResponseNotFound #추가

from speech_recognition import *
from pyautogui import *
import clipboard
import keyboard
import pyaudio
import time # 필요한 모듈 불러오기

import datetime





def read_voice():
    r = Recognizer()
    mic = Microphone()
    with mic as source:
        audio = r.listen(source)
    voice_data = r.recognize_google(audio, language='ko')
    return voice_data # 값 반환




def voice(request):
    return render(request, 'elections/voice text.html')


def record(request):
    try:
        f1=open("C:\\xampp\\htdocs\\django\\voice\\elections\\templates\\elections\\voice text2","rt",encoding="utf-8")
        c1=f1.read()
        voice = read_voice() # 음성 인식
        time.sleep(0.1)
        f=open("C:\\xampp\\htdocs\\django\\voice\\elections\\templates\\elections\\voice text2","wt",encoding="utf-8")
        c=voice
        f.write(c1+c+" ")
        f.close()
        return render(request, 'elections/reload.html')
    except:
        return render(request, 'elections/exc.html')

def rel(request):
    return render(request, 'elections/reload.html')





def reset(request):
    f=open("C:\\xampp\\htdocs\\django\\voice\\elections\\templates\\elections\\voice text2","wt",encoding="utf-8")
    c=voice
    f.write("")
    f.close()
    return render(request, 'elections/reset.html')





from .models import aaa
def index(request):
    aaas = aaa.objects.all()
    str = ""
    for rec in aaas:
        str += "<p>{}기호 {}번 ({})</p>".format(rec.a1, rec.a2, rec.a3)
    return HttpResponse(str)



def save(request):
    return render(request, 'elections/save.html')



def save2(request):
    if request.method == 'POST':
        f=open("C:\\xampp\\htdocs\\django\\voice\\elections\\templates\\elections\\voice text2","rt",encoding="utf-8")
        c=f.read()
        post = aaa()
        post.a1 = request.POST['sub']
        post.a2 = c
        post.a3 = datetime.datetime.now()
        post.save()
        return render(request, 'elections/save2.html')


def dell(request):
    if request.method == 'POST':
        dell = aaa.objects.get(a1 = request.POST['del'])
        dell.delete()
        return render(request, 'elections/save2.html')



# a1 제목 ,a2 내용 ,a3 날짜

def list(request):
    aaas = aaa.objects.all()
    context = {'aaas': aaas}
    return render(request, 'elections/list.html', context)


def abc(request):
    if request.GET.get('save') != None:
        save = request.GET.get('save')
        f=open("C:\\xampp\\htdocs\\django\\voice\\elections\\templates\\elections\\voice text2","wt",encoding="utf-8")
        c=save
        f.write(c)
        f.close()
        return render(request, 'elections/reload.html')


