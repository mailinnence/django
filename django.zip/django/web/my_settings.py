
#my_settings.py
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', #1
        'NAME': 'django_insta',                  
        'USER': 'root',                          
        'PASSWORD': '',                  
        'HOST': 'localhost',                     
        'PORT': '3306',
    }
}
SECRET_KEY ='django-insecure-a*wcw!uw612xt#47#l38n=p3vo#e5=4o4j636o3_sq5yuvd&us'

