from django.db import models



class user(models.Model):
    objects = models.Manager()
    web_id = models.CharField(max_length=30)
    pw = models.CharField(max_length=30)
    pwd_conf = models.CharField(max_length=30)
    email = models.EmailField(unique=True, max_length=50)
    gender = models.CharField(max_length=30)
    birth = models.CharField(max_length=30)
    number1 = models.CharField(max_length=4)
    number2 = models.CharField(max_length=4)
    start= models.DateTimeField(auto_now_add=True)

