from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .models import user
import datetime
from django.http import HttpResponseRedirect
from django.db.models import Sum
from django.http import HttpResponseNotFound #추가



def index(request):
    return HttpResponse("Hello world")

#post 방식
def main(request):
    return render(request, 'elections/login_form.html')

#회원가입 폼
def member_form(request):
    return render(request, 'elections/member_form.html')


# def member_insert(request):
#     if request.method == 'POST':
#     return render(request, 'elections/member_form.html')



def sign(request):
     if request.method == 'POST':
         post = user()
         post.pw = request.POST['pw']
         post.save()
         return render(request, 'elections/sign.html') # render는 view에서 템플릿에 전달할 데이타를 Dictionary로 전달한다
     else:
         post = Post.objects.all()
         return render(request, 'elections/sign.html', {'post':post})





